---
format: workdsh-team-document
version: 1
lead: agents/lead.md
members:
  - key: flood
    file: agents/flood.md
  - key: cartography
    file: agents/cartography.md
  - key: interpretation
    file: agents/interpretation.md
workflows:
  - id: rapid-assessment
    title: 灾情快速评估
    trigger: 突发灾害，需要在最短时间内给出受灾范围初判。
    deliverable: 应急成果图（含时相、覆盖范围与置信度标注）+ 待验证清单。
    stages:
      - id: layout
        worker: cartography
        dependsOn: []
      - id: method
        worker: flood
        dependsOn: []
      - id: verify
        worker: interpretation
        dependsOn:
          - method
---

# 应急响应团队

灾情发生后的快速遥感评估：先给出能用的结论，并明确标出它有多不可靠。

成员方法保存在 agents/；场景触发、执行依赖和成果要求保存在本文件头部。
