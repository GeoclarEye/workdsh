---
format: workdsh-team-document
version: 1
lead: agents/lead.md
members:
  - key: procurement
    file: agents/procurement.md
  - key: interpretation
    file: agents/interpretation.md
  - key: governance
    file: agents/governance.md
  - key: cartography
    file: agents/cartography.md
workflows:
  - id: monitoring-delivery
    title: 区域监测成果交付
    trigger: 需求方要一份某区域、某时段的监测成果，并希望结论可溯源。
    deliverable: 监测成果：数据来源与口径、方法与参数、结果与精度局限、成果图、待验证清单。
    stages:
      - id: data
        worker: procurement
        dependsOn: []
      - id: analysis
        worker: interpretation
        reviewer: governance
        dependsOn:
          - data
      - id: atlas
        worker: cartography
        dependsOn:
          - analysis
---

# 遥感监测团队

交付一份可直接使用的区域监测成果：数据来源与口径、方法与参数、精度与局限、成果图，全部可溯源。

成员方法保存在 agents/；场景触发、执行依赖和成果要求保存在本文件头部。
