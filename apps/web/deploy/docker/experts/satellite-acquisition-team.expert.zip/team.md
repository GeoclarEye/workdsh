---
format: workdsh-team-document
version: 1
lead: agents/lead.md
members:
  - key: gis
    file: agents/gis.md
  - key: procurement
    file: agents/procurement.md
  - key: interpretation
    file: agents/interpretation.md
workflows:
  - id: tasking-intake
    title: 承接拍摄需求
    trigger: 需求方提出要对某块区域或某个目标安排成像。
    deliverable: 可下单的拍摄方案：可行性判断、成本对照、待确认项。
    stages:
      - id: scope
        worker: gis
        dependsOn: []
      - id: budget
        worker: procurement
        dependsOn:
          - scope
      - id: interpretability
        worker: interpretation
        dependsOn:
          - scope
---

# 卫星拍摄团队

把"我要拍某块地"的诉求变成可下单的拍摄方案：可行性判断、成本对照、待确认项，一次说清。

成员方法保存在 agents/；场景触发、执行依赖和成果要求保存在本文件头部。
